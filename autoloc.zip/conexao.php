<?php 
$host="localhost";
$port=3303;
$socket="";
$user="root";
$password="alunolab";
$dbname="autoloc";

$con = new mysqli($host, $user, $password, $dbname, $port, $socket)
	or die ('Could not connect to the database server' . mysqli_connect_error());

//$con->close();
if ($con->connect_error) { 
 
    die( 
        "Erro na conexão: " 
        . $con->connect_error 
    ); 
 
} 
$con->set_charset("utf8mb4"); 
?> 
