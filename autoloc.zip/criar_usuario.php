<?php 
require "conexao.php"; 
$nome = 
"Administrador"; 
$login = 
"admin"; 
$senha = 
password_hash( 
"1234", 
PASSWORD_DEFAULT 
); 
$perfil = 
"Administrador"; 
$stmt = 
$con->prepare( 
"INSERT INTO usuario 
(nome,login,senha,perfil) 
VALUES 
(?,?,?,?)" 
); 
$stmt->bind_param( 
"ssss", 
$nome, 
$login, 
$senha, 
$perfil 
); 
if( 
$stmt->execute() 
){ 
echo 
"Usuário criado!"; 
}else{ 
echo 
"Erro: " 
.$stmt->error; 
} 
?>