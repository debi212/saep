<?php 
require "conexao.php"; 
$nome = $_POST['nome']; 
$cpf = $_POST['cpf']; 
$cnh = $_POST['cnh']; 
$telefone = $_POST['telefone']; 
$email = $_POST['email']; 
$endereco = $_POST['endereco']; 
$sql = 
"INSERT INTO cliente 
(nome, cpf, cnh, telefone, email, endereco) 
VALUES (?, ?, ?, ?, ?, ?)"; 
$stmt = $con->prepare($sql); 
$stmt->bind_param( 
"ssssss", 
$nome, 
$cpf, 
$cnh, 
$telefone, 
$email, 
$endereco 
); 
if ($stmt->execute()) { 
echo "Cliente cadastrado com sucesso!"; 
} else { 
echo "Erro: " . $stmt->error; 
} 
?> 