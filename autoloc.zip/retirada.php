<?php 
require "conexao.php"; 
$resultado = 
$con->query( 
"SELECT 
l.id_locacao, 
c.nome, 
v.modelo, 
v.placa 
FROM locacao l 
INNER JOIN cliente c 
ON l.id_cliente = 
c.id_cliente 
INNER JOIN veiculo v 
ON l.id_veiculo = 
v.id_veiculo 
WHERE 
l.status='Reservada'" 
); 
?> 
<h1> 
Retirada do Veículo 
</h1> 
<?php 
while( 
$l = 
$resultado->fetch_assoc() 
){ 
?> 
<p> 
<?= $l['nome'] ?> - 
<?= $l['modelo'] ?> - 
<?= $l['placa'] ?> 
<a href= 
"realizar_retirada.php?id= 
<?= $l['id_locacao'] ?>"> 
RETIRAR 
</a> 
</p> 
<?php } ?>