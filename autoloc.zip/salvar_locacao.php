<?php 
require "conexao.php"; 
$id_cliente = 
intval($_POST['cliente']); 
$id_veiculo = 
intval($_POST['veiculo']); 
$retirada = 
$_POST['retirada']; 
$devolucao = 
$_POST['devolucao']; 
/* 
Consultar veículo 
*/ 
$stmt = 
$con->prepare( 
"SELECT * 
FROM veiculo 
WHERE id_veiculo=?" 
); 
$stmt->bind_param( 
"i", 
$id_veiculo 
); 
$stmt->execute(); 
$veiculo = 
$stmt ->get_result() ->fetch_assoc(); 
if( 
$veiculo['status'] 
!= 
'Disponível' 
){ 
die( 
"Veículo indisponível." 
); 
} 
$valor_diaria = 
$veiculo['valor_diaria']; 
/* 
Criar locação 
*/ 
$stmt = 
$con->prepare( 
"INSERT INTO locacao 
( 
id_cliente, 
id_veiculo, 
data_retirada, 
data_prevista_devolucao, 
valor_diaria, 
status 
) 
VALUES 
(?,?,?,?,?,'Reservada')" 
); 
$stmt->bind_param( 
"iissd", 
$id_cliente, 
$id_veiculo, 
$retirada, 
$devolucao, 
$valor_diaria 
); 
$stmt->execute(); 
/* 
Reservar veículo 
*/ 
$stmt = 
$con->prepare( 
"UPDATE veiculo 
SET status='Reservado' 
WHERE id_veiculo=?" 
); 
$stmt->bind_param( 
"i", 
$id_veiculo 
); 
$stmt->execute(); 
echo 
"Locação realizada com sucesso!"; 
?>