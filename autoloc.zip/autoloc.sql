CREATE DATABASE autoloc 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci; 
USE autoloc; 

CREATE TABLE cliente ( 
id_cliente INT PRIMARY KEY AUTO_INCREMENT, 
nome VARCHAR(100) NOT NULL, 
cpf VARCHAR(14) NOT NULL UNIQUE, 
cnh VARCHAR(20) NOT NULL UNIQUE, 
telefone VARCHAR(20), 
email VARCHAR(100), 
endereco VARCHAR(150) 
); 

DESCRIBE cliente; 

INSERT INTO cliente (nome, cpf, cnh, telefone, email, endereco) VALUES 
('Carlos Silva', '111.111.111-11', 'CNH001', '21999990001', 'carlos@email.com', 'Rio de Janeiro'), 
('Maria Souza', '222.222.222-22', 'CNH002', '21999990002', 'maria@email.com', 'Niterói'), 
( 'Pedro Santos', '333.333.333-33', 'CNH003', '21999990003', 'pedro@email.com', 'Duque de Caxias');

SELECT * 
FROM cliente; 

CREATE TABLE veiculo ( 
 
    id_veiculo INT 
    PRIMARY KEY 
    AUTO_INCREMENT, 
 
    placa VARCHAR(10) 
    NOT NULL 
    UNIQUE, 
 
    marca VARCHAR(50) 
    NOT NULL, 
 
    modelo VARCHAR(50) 
    NOT NULL, 
 
    ano INT, 
 
    categoria VARCHAR(50), 
 
    valor_diaria DECIMAL(10,2), 
 
    status VARCHAR(20) 
    DEFAULT 'Disponível' 
 
);

DESCRIBE veiculo;


INSERT INTO veiculo 
( 
placa, 
marca, 
modelo, 
ano, 
categoria, 
valor_diaria, 
status 
) 
VALUES 
( 
'ABC1D23', 
'Fiat', 
'Argo', 
2024, 
'Econômico', 
120, 
'Disponível' 
), 
( 
'DEF4G56', 
'Chevrolet', 
'Onix', 
2024, 
'Econômico', 
130, 
'Disponível' 
), 
( 
'JKL1M23', 
'Toyota', 
'Corolla', 
2024, 
'Sedan', 
250, 
'Disponível' 
), 
( 
'NOP4Q56', 
'Jeep', 
'Renegade', 
2024, 
'SUV', 
280, 
'Disponível' 
), 
( 
'FGH1I23', 
'Jeep', 
'Compass', 
2024, 
'SUV', 
350, 
'Manutenção' 
); 

SELECT * 
FROM veiculo;

CREATE TABLE locacao ( 
 
    id_locacao INT 
    PRIMARY KEY 
    AUTO_INCREMENT, 
 
    id_cliente INT NOT NULL, 
 
    id_veiculo INT NOT NULL, 
 
    data_retirada DATE NOT NULL, 
 
    data_prevista_devolucao 
    DATE NOT NULL, 
 
    data_devolucao DATE, 
 
    valor_diaria 
    DECIMAL(10,2), 
 
    valor_total 
    DECIMAL(10,2), 
 
    status VARCHAR(30) 
    DEFAULT 'Reservada', 
 
    FOREIGN KEY 
    (id_cliente) 
    REFERENCES 
    cliente(id_cliente), 
 
    FOREIGN KEY 
    (id_veiculo) 
    REFERENCES 
    veiculo(id_veiculo) 
 
); 

DESCRIBE locacao; 

SELECT * 
FROM locacao; 

SELECT 
placa, 
modelo, 
status 
FROM veiculo;

SELECT * 
FROM locacao;

SELECT 
modelo, 
status 
FROM veiculo; 

SELECT * 
FROM locacao; 

SELECT 
modelo, 
status 
FROM veiculo;

CREATE TABLE usuario ( 
id_usuario INT 
PRIMARY KEY 
AUTO_INCREMENT, 
nome VARCHAR(100) 
NOT NULL, 
login VARCHAR(50) 
NOT NULL 
UNIQUE, 
senha VARCHAR(255) 
NOT NULL, 
perfil VARCHAR(30) 
);