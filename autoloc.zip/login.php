<?php 
session_start(); 
require "conexao.php"; 
$login = 
$_POST['login']; 
$senha = 
$_POST['senha']; 
$stmt = 
$con->prepare( 
"SELECT * 
FROM usuario 
WHERE login=?" 
); 
$stmt->bind_param( 
"s", 
$login 
); 
$stmt->execute(); 
$resultado = 
$stmt->get_result(); 
if( 
$resultado->num_rows == 1 
){ 
$usuario = 
$resultado->fetch_assoc(); 
if( 
password_verify( 
$senha, 
$usuario['senha'] 
) 
){ 
$_SESSION['usuario'] = 
$usuario['nome']; 
header( 
"Location: dashboard.php" 
); 
exit; 
} 
} 
echo 
"Usuário ou senha incorretos."; 
?>