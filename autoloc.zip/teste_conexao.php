<?php 
require "conexao.php"; 
echo "<h2>Conexão realizada com sucesso!</h2>"; 
?>