<?php require "conexao.php";
 $id = intval($_GET['id']);
  $stmt = $con->prepare( "SELECT l.*,
   v.modelo,
    v.id_veiculo 
    FROM locacao l 
    INNER JOIN veiculo v 
    ON l.id_veiculo = v.id_veiculo 
    WHERE l.id_locacao=?" ); 
    $stmt->bind_param( "i", $id ); 
    $stmt->execute(); 
    $locacao = $stmt ->get_result() ->fetch_assoc(); 
    /* Data da devolução */ 
    $data_devolucao = date("Y-m-d"); 
    /* Calcular diárias */ 
    $entrada = new DateTime( $locacao['data_retirada'] ); 
    $saida = new DateTime( $data_devolucao ); 
    $diferenca = $entrada->diff($saida); 
    $dias = $diferenca->days; 
    if($dias < 1){ $dias = 1; } $total = $dias * $locacao['valor_diaria'];
     /* Atualizar locação */
      $stmt = $con->prepare( 
        "UPDATE locacao SET data_devolucao=?,
         valor_total=?, 
         status='Finalizada' WHERE id_locacao=?" ); 
         $stmt->bind_param( "sdi", $data_devolucao, $total, $id );
          $stmt->execute(); 
          /* Liberar veículo */ 
          $stmt = $con->prepare( 
            "UPDATE veiculo 
            SET status='Disponível' 
            WHERE id_veiculo=?" ); 
            $stmt->bind_param( 
                "i", $locacao['id_veiculo'] );
                 $stmt->execute();
                  ?> <h1> Devolução concluída </h1>
                   <p> Veículo: <?= $locacao['modelo'] ?>
                 </p> <p> Diárias: <?= $dias ?> </p> 
                 <p> Valor da diária: R$ <?= number_format( $locacao['valor_diaria'],
                  2, ',', '.' ) ?> </p>
                   <h2> Total: R$ <?= number_format( $total, 2, ',', '.' ) ?> 
                </h2> 