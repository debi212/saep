<?php 
echo "<h1>AutoLoc</h1>";
echo "<p>PHP funcionando corretamente!</p>"; 
?> 