<?php 
session_start(); 
if( 
!isset( 
$_SESSION['usuario'] 
) 
){ 
header( 
"Location: index.php" 
); 
exit; 
} 
require "conexao.php"; 
?> 
<h1>AUTOLOC</h1> 
<h2> 
Bem-vindo, 
<?= htmlspecialchars( 
$_SESSION['usuario'] 
) ?> 
</h2> 
<hr> 
<a href="clientes.php"> 
Clientes 
</a> 
<br> 
<a href="veiculos.php"> 
Veículos 
</a> 
<br> 
<a href="nova_locacao.php"> 
Nova Locação 
</a> 
<br> 
<a href="locacoes.php"> 
Locações 
</a> 
<br> 
<a href="retirada.php"> 
Retirada 
</a> 
<br> 
<a href="devolucao.php"> 
Devolução 
</a> 
<br><br> 
<a href="logout.php"> 
Sair 
</a>