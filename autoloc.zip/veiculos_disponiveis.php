<?php 
require "conexao.php"; 
$resultado = 
$con->query( 
"SELECT * 
FROM veiculo 
WHERE status='Disponível' 
ORDER BY modelo" 
); 
?> 
<h1> 
Veículos Disponíveis 
</h1> 
<?php 
while( 
$v = 
$resultado->fetch_assoc() 
){ 
echo 
$v['marca'] 
. " " 
. $v['modelo'] 
. "<br>"; 
} 
 
?>