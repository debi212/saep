<?php 
require "conexao.php"; 
$sql = 
"SELECT 
l.id_locacao, 
c.nome, 
v.placa, 
v.marca, 
v.modelo, 
l.data_retirada, 
l.data_prevista_devolucao, 
l.status 
FROM locacao l 
INNER JOIN cliente c 
ON l.id_cliente = 
c.id_cliente 
INNER JOIN veiculo v 
ON l.id_veiculo = 
v.id_veiculo 
ORDER BY 
l.data_retirada"; 
$resultado = 
$con->query($sql); 
?> 
<h1>Locações</h1> 
<table border="1"> 
<tr> 
<th>Código</th> 
<th>Cliente</th> 
<th>Veículo</th> 
<th>Retirada</th> 
<th>Devolução</th> 
<th>Status</th> 
</tr> 
<?php 
while( 
$l = 
$resultado->fetch_assoc() 
){ 
?> 
<tr> 
<td> 
<?= $l['id_locacao'] ?> 
</td> 
<td> 
<?= $l['nome'] ?> 
</td> 
<td> 
<?= $l['marca'] ?> 
<?= $l['modelo'] ?> - 
<?= $l['placa'] ?> 
</td> 
<td> 
<?= $l['data_retirada'] ?> 
</td> 
<td> 
<?= $l['data_prevista_devolucao'] ?> 
</td> 
<td> 
<?= $l['status'] ?> 
</td> 
</tr> 
<?php } ?> 
</table>