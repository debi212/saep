<?php 
require "conexao.php"; 
$id = 
intval($_GET['id']); 
/* 
Localizar locação 
*/ 
$stmt = 
$con->prepare( 
"SELECT id_veiculo 
FROM locacao 
WHERE id_locacao=?" 
); 
$stmt->bind_param( 
"i", 
$id 
); 
$stmt->execute(); 
$locacao = 
$stmt ->get_result() ->fetch_assoc(); 
$id_veiculo = 
$locacao['id_veiculo']; 
/* 
Alterar locação 
*/ 
$stmt = 
$con->prepare( 
"UPDATE locacao 
SET status='Em andamento' 
WHERE id_locacao=?" 
); 
$stmt->bind_param( 
"i", 
$id 
); 
$stmt->execute(); 
/* 
Alterar veículo 
*/ 
$stmt = 
$con->prepare( 
"UPDATE veiculo 
SET status='Alugado' 
WHERE id_veiculo=?" 
); 
$stmt->bind_param( 
"i", 
$id_veiculo 
); 
$stmt->execute(); 
echo 
"Retirada realizada com sucesso!"; 
?>