<?php 
 
require "conexao.php"; 
 
$clientes = 
$con->query( 
"SELECT * 
 FROM cliente 
 ORDER BY nome" 
); 
$veiculos = 
$con->query( 
"SELECT * 
FROM veiculo 
WHERE status='Disponível' 
ORDER BY modelo" 
); 
?> 
<h1>Nova Locação</h1> 
<form 
action="salvar_locacao.php" 
method="POST"> 
Cliente: 
<select name="cliente"> 
<?php 
while( 
$c = 
$clientes->fetch_assoc() 
){ 
?> 
<option 
value="<?= $c['id_cliente'] ?>"> 
<?= htmlspecialchars($c['nome']) ?> 
</option> 
<?php } ?> 
</select> 
<br><br> 
Veículo: 
<select name="veiculo"> 
<?php 
while( 
$v = 
$veiculos->fetch_assoc() 
){ 
?> 
<option 
value="<?= $v['id_veiculo'] ?>"> 
<?= $v['marca'] ?> 
<?= $v['modelo'] ?> - 
<?= $v['placa'] ?> 
</option> 
<?php } ?> 
</select> 
<br><br> 
Retirada: 
<input 
type="date" 
name="retirada" 
required> 
<br><br> 
Devolução prevista: 
<input 
type="date" 
name="devolucao" 
required> 
<br><br> 
<button> 
Realizar Locação 
</button> 
</form> 