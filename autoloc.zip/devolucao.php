<?php 
require "conexao.php"; 
$resultado = 
$con->query( 
"SELECT 
l.id_locacao, 
c.nome, 
v.modelo, 
v.placa 
FROM locacao l 
INNER JOIN cliente c 
ON l.id_cliente = 
c.id_cliente 
INNER JOIN veiculo v 
ON l.id_veiculo = 
v.id_veiculo 
WHERE 
l.status='Em andamento'" 
); 
?> 
<h1>Devoluções</h1> 
<?php 
while( 
$l = 
$resultado->fetch_assoc() 
){ 
?> 
<p> 
<?= $l['nome'] ?> 
- 
<?= $l['modelo'] ?> 
<a href= 
"realizar_devolucao.php?id= 
<?= $l['id_locacao'] ?>"> 
DEVOLVER 
</a> 
</p> 
<?php } ?>