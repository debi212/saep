<?php 

require "conexao.php"; 
$sql = "SELECT * 
FROM cliente 
ORDER BY nome"; 
$resultado = $con->query($sql); 

$busca = $_GET['busca'] ?? ''; 
 
if ($busca != '') { 
 
    $termo = 
    "%" . $busca . "%"; 
 
    $sql = 
    "SELECT * 
    FROM cliente 
    WHERE nome LIKE ? 
    OR cpf LIKE ? 
    OR cnh LIKE ? 
    ORDER BY nome"; 
 
    $stmt = 
    $con->prepare($sql); 
 
    $stmt->bind_param( 
        "sss", 
        $termo, 
        $termo, 
        $termo 
    ); 
 
    $stmt->execute(); 
 
    $resultado = 
    $stmt->get_result(); 
 
} else { 
 
    $resultado = 
    $con->query( 
        "SELECT * 
        FROM cliente 
        ORDER BY nome  " 
    ); 
 
} 

?> 

<form method="GET"> 
<input 
type="text" 
name="busca" 
placeholder="Nome, CPF ou CNH"> 
<button type="submit"> 
Pesquisar 
</button> 
</form> 
<br>

<h1>Clientes</h1> 
<table border="1"> 
<tr> 
<th>Código</th> 
<th>Nome</th> 
<th>CPF</th> 
<th>CNH</th> 
<th>Telefone</th> 
</tr> 

<?php 
while ($cliente = $resultado->fetch_assoc()) { 
?> 
<tr> 
<td> 
<?= $cliente['id_cliente'] ?> 
</td> 
<td> 
<?= htmlspecialchars($cliente['nome']) ?> 
</td> 
<td> 
<?= htmlspecialchars($cliente['cpf']) ?> 
</td> 
<td> 
<?= htmlspecialchars($cliente['cnh']) ?> 
</td> 
<td> 
<?= htmlspecialchars($cliente['telefone']) ?> 
</td> 
</tr> 
<?php 
} 
?> 
</table>