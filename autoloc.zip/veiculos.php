<?php 
require "conexao.php"; 
$resultado = 
$con->query( 
"SELECT * 
FROM veiculo 
ORDER BY modelo" 
); 
?> 
<h1>Veículos</h1> 
<table border="1"> 
<tr> 
<th>Placa</th> 
<th>Marca</th> 
<th>Modelo</th> 
<th>Ano</th> 
<th>Categoria</th> 
<th>Diária</th> 
<th>Status</th> 
</tr> 
<?php 
while( 
$v = 
$resultado->fetch_assoc() 
){ 
?> 
<tr> 
<td> 
<?= $v['placa'] ?> 
</td> 
<td> 
<?= $v['marca'] ?> 
</td> 
<td> 
<?= $v['modelo'] ?> 
</td> 
<td> 
<?= $v['ano'] ?> 
</td> 
<td> 
<?= $v['categoria'] ?> 
</td> 
<td> 
R$ 
<?= number_format( 
$v['valor_diaria'], 
2, 
',', 
'.' 
) ?> 
</td> 
<td> 
<?= $v['status'] ?> 
</td> 
</tr> 
<?php } ?> 
</table> 