<?php

/*
==========================================================
 TESTE DE INTEGRA��O
 Sistema: Biblioteca Escolar

 Unidade Curricular: Testes de Sistemas
 Objetivo:
 Testar a integra��o PHP + MySQL + relacionamento
 entre autores e livros.

 Marcelo Rocha
 SENAI Benfica
==========================================================
*/

require_once "../conecta.php";

$resultados = [];

$testesExecutados = 0;
$testesAprovados = 0;
$testesReprovados = 0;


/*
----------------------------------------------------------
FUN��O DE REGISTRO DOS TESTES
----------------------------------------------------------
*/

function testar($descricao, $resultado)
{
    global $resultados;
    global $testesExecutados;
    global $testesAprovados;
    global $testesReprovados;

    $testesExecutados++;

    if ($resultado) {

        $status = "APROVADO";
        $testesAprovados++;

    } else {

        $status = "REPROVADO";
        $testesReprovados++;
    }

    $resultados[] = [
        "descricao" => $descricao,
        "status" => $status
    ];
}


/*
----------------------------------------------------------
IN�CIO DA TRANSA��O

Todos os dados criados durante o teste ser�o apagados
automaticamente no final com ROLLBACK.
----------------------------------------------------------
*/

$con->begin_transaction();

try {


/*
==========================================================
TESTE 01
CONEX�O PHP + MYSQL
==========================================================
*/

testar(
    "Conex�o do PHP com o banco de dados MySQL",
    !$con->connect_error
);


/*
==========================================================
TESTE 02
CADASTRO DE AUTOR
==========================================================
*/

$nomeAutor = "Autor Teste Integra��o";

$stmt = $con->prepare(
    "INSERT INTO autores (nome) VALUES (?)"
);

$stmt->bind_param(
    "s",
    $nomeAutor
);

$resultado = $stmt->execute();

$idAutor = $con->insert_id;

testar(
    "PHP consegue cadastrar um autor no MySQL",
    $resultado && $idAutor > 0
);


/*
==========================================================
TESTE 03
CONSULTA DO AUTOR
==========================================================
*/

$stmt = $con->prepare(
    "SELECT nome
     FROM autores
     WHERE id_autor = ?"
);

$stmt->bind_param(
    "i",
    $idAutor
);

$stmt->execute();

$autor = $stmt
            ->get_result()
            ->fetch_assoc();

testar(
    "Autor cadastrado pode ser recuperado do banco",
    $autor &&
    $autor["nome"] === $nomeAutor
);


/*
==========================================================
TESTE 04
CADASTRO DE LIVRO ASSOCIADO AO AUTOR
==========================================================
*/

$titulo = "Livro para Teste de Integra��o";
$editora = "Editora SENAI";
$ano = 2026;
$paginas = 250;

$stmt = $con->prepare(

    "INSERT INTO livros
    (
        titulo,
        id_autor,
        editora,
        ano_publicacao,
        paginas
    )
    VALUES (?, ?, ?, ?, ?)"

);

$stmt->bind_param(

    "sisii",

    $titulo,
    $idAutor,
    $editora,
    $ano,
    $paginas

);

$resultado = $stmt->execute();

$idLivro = $con->insert_id;

testar(
    "Cadastro de livro associado ao autor",
    $resultado && $idLivro > 0
);


/*
==========================================================
TESTE 05
INTEGRA��O ENTRE AUTORES E LIVROS
INNER JOIN
==========================================================
*/

$stmt = $con->prepare(

    "SELECT
        livros.titulo,
        autores.nome AS autor

     FROM livros

     INNER JOIN autores
     ON livros.id_autor = autores.id_autor

     WHERE livros.id_livro = ?"

);

$stmt->bind_param(
    "i",
    $idLivro
);

$stmt->execute();

$registro = $stmt
                ->get_result()
                ->fetch_assoc();

testar(

    "Relacionamento entre Livro e Autor utilizando INNER JOIN",

    $registro &&
    $registro["titulo"] === $titulo &&
    $registro["autor"] === $nomeAutor

);


/*
==========================================================
TESTE 06
EDI��O DO LIVRO
==========================================================
*/

$novoTitulo = "Livro Alterado pelo Teste";
$novasPaginas = 300;

$stmt = $con->prepare(

    "UPDATE livros

     SET titulo = ?,
         paginas = ?

     WHERE id_livro = ?"

);

$stmt->bind_param(

    "sii",

    $novoTitulo,
    $novasPaginas,
    $idLivro

);

$stmt->execute();


/*
Consulta para verificar se realmente alterou.
*/

$stmt = $con->prepare(

    "SELECT titulo, paginas

     FROM livros

     WHERE id_livro = ?"

);

$stmt->bind_param(
    "i",
    $idLivro
);

$stmt->execute();

$livroAlterado = $stmt
                    ->get_result()
                    ->fetch_assoc();


testar(

    "Atualiza��o do livro no banco de dados",

    $livroAlterado &&
    $livroAlterado["titulo"] === $novoTitulo &&
    $livroAlterado["paginas"] == $novasPaginas

);


/*
==========================================================
TESTE 07
EXCLUS�O DO LIVRO
==========================================================
*/

$stmt = $con->prepare(

    "DELETE FROM livros
     WHERE id_livro = ?"

);

$stmt->bind_param(
    "i",
    $idLivro
);

$stmt->execute();


/*
Verifica se o livro deixou de existir.
*/

$stmt = $con->prepare(

    "SELECT id_livro

     FROM livros

     WHERE id_livro = ?"

);

$stmt->bind_param(
    "i",
    $idLivro
);

$stmt->execute();

$existeLivro = $stmt
                    ->get_result()
                    ->num_rows;


testar(
    "Exclus�o de livro",
    $existeLivro === 0
);


/*
==========================================================
TESTE 08
INTEGRIDADE DA CHAVE ESTRANGEIRA
==========================================================
*/

$tituloTeste = "Livro Autor Inexistente";
$autorInexistente = 999999;
$editoraTeste = "Teste";
$anoTeste = 2026;
$paginasTeste = 100;

$stmt = $con->prepare(

    "INSERT INTO livros
    (
        titulo,
        id_autor,
        editora,
        ano_publicacao,
        paginas
    )

    VALUES (?, ?, ?, ?, ?)"

);

$stmt->bind_param(

    "sisii",

    $tituloTeste,
    $autorInexistente,
    $editoraTeste,
    $anoTeste,
    $paginasTeste

);

/*
Desativa temporariamente exce��es do mysqli
para podermos analisar o retorno.
*/

mysqli_report(MYSQLI_REPORT_OFF);

$resultadoFK = $stmt->execute();

mysqli_report(
    MYSQLI_REPORT_ERROR |
    MYSQLI_REPORT_STRICT
);


testar(

    "Banco impede cadastro de livro com autor inexistente",

    $resultadoFK === false

);


/*
==========================================================
TESTE 09
EXCLUS�O EM CASCATA
==========================================================
*/

/*
Primeiro cadastramos outro livro.
*/

$tituloCascata = "Teste Delete Cascade";

$stmt = $con->prepare(

    "INSERT INTO livros
    (
        titulo,
        id_autor,
        editora,
        ano_publicacao,
        paginas
    )

    VALUES (?, ?, ?, ?, ?)"

);

$stmt->bind_param(

    "sisii",

    $tituloCascata,
    $idAutor,
    $editora,
    $ano,
    $paginas

);

$stmt->execute();

$idLivroCascata = $con->insert_id;


/*
Agora exclu�mos o autor.
*/

$stmt = $con->prepare(

    "DELETE FROM autores
     WHERE id_autor = ?"

);

$stmt->bind_param(
    "i",
    $idAutor
);

$stmt->execute();


/*
Verifica se o livro tamb�m foi eliminado.
*/

$stmt = $con->prepare(

    "SELECT id_livro
     FROM livros
     WHERE id_livro = ?"

);

$stmt->bind_param(
    "i",
    $idLivroCascata
);

$stmt->execute();

$livroCascata = $stmt
                    ->get_result()
                    ->num_rows;


testar(

    "ON DELETE CASCADE remove livros quando o autor � exclu�do",

    $livroCascata === 0

);


/*
----------------------------------------------------------
ROLLBACK

Desfaz todas as altera��es realizadas pelo teste.
----------------------------------------------------------
*/

$con->rollback();


} catch (Throwable $erro) {

    $con->rollback();

    $resultados[] = [

        "descricao" =>
            "Erro durante a execu��o: "
            . $erro->getMessage(),

        "status" => "REPROVADO"

    ];

    $testesReprovados++;
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

<meta charset="UTF-8">

<title>Teste de Integra��o - Biblioteca</title>

<style>

body {

    font-family: Arial, sans-serif;

    background: #f4f6f8;

    margin: 0;

}

.container {

    width: 90%;
    max-width: 1000px;

    margin: 30px auto;

    background: white;

    padding: 25px;

    border-radius: 8px;

}

h1 {

    color: #0b2a67;

}

.resumo {

    display: flex;

    gap: 20px;

    margin-bottom: 25px;

}

.card {

    padding: 15px;

    border-radius: 6px;

    background: #eeeeee;

    min-width: 150px;

}

table {

    width: 100%;

    border-collapse: collapse;

}

th,
td {

    border: 1px solid #ccc;

    padding: 10px;

}

th {

    background: #0b2a67;

    color: white;

}

.aprovado {

    color: green;

    font-weight: bold;

}

.reprovado {

    color: red;

    font-weight: bold;

}

</style>

</head>

<body>

<div class="container">

<h1>Teste de Integra��o</h1>

<p>
Sistema de Biblioteca Escolar
</p>

<p>
<strong>Unidade Curricular:</strong>
Testes de Sistemas
</p>


<div class="resumo">

<div class="card">

<strong>Executados</strong>

<h2>
<?= $testesExecutados ?>
</h2>

</div>


<div class="card">

<strong>Aprovados</strong>

<h2>
<?= $testesAprovados ?>
</h2>

</div>


<div class="card">

<strong>Reprovados</strong>

<h2>
<?= $testesReprovados ?>
</h2>

</div>

</div>


<table>

<tr>

<th>N�</th>

<th>Teste de Integra��o</th>

<th>Resultado</th>

</tr>


<?php

$numero = 1;

foreach ($resultados as $teste):

?>

<tr>

<td>
<?= $numero++ ?>
</td>

<td>
<?= htmlspecialchars($teste["descricao"]) ?>
</td>

<td class="
<?= $teste["status"] === "APROVADO"
    ? "aprovado"
    : "reprovado" ?>
">

<?= $teste["status"] ?>

</td>

</tr>

<?php endforeach; ?>

</table>


<h2>Resultado Final</h2>

<?php if ($testesReprovados == 0): ?>

<p class="aprovado">

? INTEGRA��O DO SISTEMA APROVADA

</p>

<?php else: ?>

<p class="reprovado">

? FORAM ENCONTRADAS FALHAS DE INTEGRA��O

</p>

<?php endif; ?>


<hr>

<p>
<strong>SENAI Benfica</strong><br>
Marcelo Rocha � Instrutor
</p>

</div>

</body>

</html>