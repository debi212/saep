document.getElementById('form_livro').addEventListener('submit', function(event) {
    const titulo = document.getElementById('titulo').value.trim();
    const autor = document.getElementById('id_autor').value;
    const editora = document.getElementById('editora').value.trim();
    const ano = document.getElementById('ano').value;
    const paginas = document.getElementById('paginas').value;

    if (titulo === '' || autor === '' || editora === '' ||
        ano === '' || paginas === '') {
        alert('Preencha todos os campos obrigat�rios.');
        event.preventDefault();
        return;
    }

    if (!/^\d{4}$/.test(ano)) {
        alert('O ano deve possuir 4 d�gitos.');
        event.preventDefault();
        return;
    }

    if (parseInt(paginas) <= 0) {
        alert('A quantidade de p�ginas deve ser maior que zero.');
        event.preventDefault();
    }
});
