<?php
$host = "127.0.0.1";
$port = 3306;
$socket = "";
$user = "root";
$password = "";
$dbname = "biblioteca";

$con = new mysqli($host, $user, $password, $dbname, $port, $socket);

if ($con->connect_error) {
    die("Erro na conex�o: " . $con->connect_error);
}

$con->set_charset("utf8mb4");
?>