<?php
include 'conecta.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);

    if ($nome !== '') {
        $stmt = $con->prepare("INSERT INTO autores (nome) VALUES (?)");
        $stmt->bind_param("s", $nome);
        $stmt->execute();
    }

    header("Location: autores.php");
    exit;
}

if (isset($_GET['excluir'])) {
    $id = (int) $_GET['excluir'];

    $stmt = $con->prepare("DELETE FROM autores WHERE id_autor = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: autores.php");
    exit;
}

$res = $con->query("SELECT * FROM autores ORDER BY nome");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Autores</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h1>Cadastro de Autores</h1>

    <form method="post">
        <label>Nome do autor:</label>
        <input type="text" name="nome" required>
        <button type="submit">Cadastrar</button>
    </form>

    <h2>Autores cadastrados</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>A��es</th>
        </tr>

        <?php while ($row = $res->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id_autor'] ?></td>
            <td><?= htmlspecialchars($row['nome']) ?></td>
            <td>
                <a href="autores.php?excluir=<?= $row['id_autor'] ?>"
                   onclick="return confirm('Deseja excluir este autor?')">
                   Excluir
                </a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <p><a href="index.php">Voltar para livros</a></p>
</div>
</body>
</html>
